#!/usr/bin/env python3
"""Portable TeX build helper for the jz-tex skill.

Uses direct engine calls and does not require latexmk or Perl.
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path


def run(cmd: list[str], cwd: Path) -> None:
    print("+", " ".join(cmd), flush=True)
    proc = subprocess.run(cmd, cwd=cwd)
    if proc.returncode != 0:
        raise SystemExit(proc.returncode)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("tex", type=Path)
    parser.add_argument("--engine", default="pdflatex",
                        choices=("pdflatex", "xelatex", "lualatex"))
    parser.add_argument("--strict", action="store_true",
                        help="fail on unresolved references/citations")
    args = parser.parse_args()

    tex = args.tex.resolve()
    if not tex.exists():
        parser.error(f"file not found: {tex}")
    cwd = tex.parent
    stem = tex.stem
    source = tex.read_text(encoding="utf-8", errors="replace")

    engine_cmd = [args.engine, "-halt-on-error", "-file-line-error",
                  "-interaction=nonstopmode", tex.name]
    run(engine_cmd, cwd)

    if "\\addbibresource" in source or (cwd / f"{stem}.bcf").exists():
        run(["biber", stem], cwd)
    elif re.search(r"\\bibliography\s*\{", source):
        run(["bibtex", stem], cwd)

    run(engine_cmd, cwd)
    run(engine_cmd, cwd)

    log_path = cwd / f"{stem}.log"
    if log_path.exists():
        log = log_path.read_text(encoding="utf-8", errors="replace")
        unresolved = [
            "There were undefined references",
            "There were undefined citations",
            "Citation `",
            "Reference `",
        ]
        hits = [needle for needle in unresolved if needle in log]
        overfull = len(re.findall(r"Overfull \\hbox", log))
        if overfull:
            print(f"warning: {overfull} overfull hbox message(s); inspect the PDF visually")
        if hits:
            print("warning: unresolved references or citations detected")
            if args.strict:
                return 2

    pdf = cwd / f"{stem}.pdf"
    if not pdf.exists():
        print("error: PDF was not produced", file=sys.stderr)
        return 3
    print(f"built: {pdf}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
