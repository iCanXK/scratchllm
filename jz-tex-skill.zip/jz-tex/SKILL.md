---
name: jz-tex
description: User-specific LaTeX authoring and editing for JZ. Use for papers, technical notes, Beamer slides, mathematical exposition, code-heavy documents, TikZ architecture diagrams, references, appendices, or any request to create, convert, revise, compile, or visually repair TeX/PDF artifacts. Prioritize mathematical precision, TikZ-native graphics, complete references, and compile/render verification with no clipping or overflow.
---

# JZ TeX Skill

Use this skill whenever producing or editing `.tex` for this user. System and current user instructions take precedence.

## 1. Deliverable contract

- Default deliverables are the editable `.tex` source and a compiled `.pdf`.
- When the project uses images, bibliography files, custom style files, or other assets, also provide a ZIP containing the complete compilable project.
- Never claim success until the expected files exist and the PDF has been compiled and visually checked.
- Do not overwrite the user's latest source unless explicitly requested. Treat the newest uploaded `.tex` as the source of truth and create a clearly named revision.
- Use descriptive, filesystem-safe names such as:
  - `topic_paper.tex`
  - `topic_slides.tex`
  - `topic_slides_v2.tex`
  - `topic_slides_fixed.tex`

## 2. General writing style

- Write concise, math-forward technical prose.
- Prefer exact definitions, equations, dimensions, and implementation details over vague summaries.
- Define every symbol at its first occurrence.
- Distinguish similar concepts explicitly, for example:
  - layer versus attention head;
  - token ID versus embedding vector;
  - logits versus probabilities;
  - ground-truth token `y_t` versus generated token `\hat y_t`;
  - training teacher forcing versus autoregressive inference.
- Use standard notation consistently:
  - `\mathbb{R}` for vector spaces;
  - `\operatorname{}` or `\mathrm{}` for named operators;
  - bold symbols only when they materially improve clarity;
  - dimensions next to important tensors and matrices.
- Preserve code, equations, examples, and the user's intended logical order when converting supplied material into LaTeX.
- Correct obvious typographical errors silently. Do not invent missing mathematical or factual content.

## 3. References and factual claims

- Include references whenever the document discusses papers, model history, architecture specifications, numerical model sizes, datasets, or other sourced claims.
- Prefer primary sources: original papers, official documentation, or the supplied source text.
- Every `\cite{...}` must resolve. No undefined citations or orphan bibliography entries.
- Use complete bibliography entries: authors, title, year, venue or publisher, and URL/DOI/arXiv identifier when appropriate.
- For Beamer:
  - keep citations short in the body;
  - place full entries on one or more references slides;
  - do not put long citation text inside narrow table cells;
  - use a dedicated reference column or a short source note below the table.
- For papers:
  - use numbered or author-year citations consistently;
  - include a final bibliography section;
  - use `hyperref` and `cleveref` for navigable citations and cross-references.

## 4. TikZ-first graphics

- Prefer authentic LaTeX/TikZ diagrams over raster images for technical architecture graphs, flowcharts, residual paths, model stacks, and mathematical schematics.
- Use consistent semantic styles for embeddings, attention, normalization, MLPs, and output layers.
- Label residual and skip paths explicitly, such as `attention residual` and `MLP residual`.
- Use arrows with clear direction and avoid crossings when practical.
- For a supplied raster figure, include it with `\includegraphics`, a caption, and a source note. Keep all text labels in TeX when feasible.
- Never allow a diagram to exceed the page or slide bounds.

Recommended slide wrapper:

```latex
\begin{adjustbox}{max width=\textwidth,
                  max totalheight=0.70\textheight,
                  center}
  \begin{tikzpicture}
    % diagram
  \end{tikzpicture}
\end{adjustbox}
```

When a diagram remains unreadable after fitting, split it across two slides instead of shrinking it excessively.

## 5. Beamer defaults

Use these defaults unless the user supplies a template or asks for a different identity:

- `\documentclass[aspectratio=169,11pt]{beamer}`.
- A restrained deep-blue and soft-pastel technical palette.
- Title slide, roadmap/chapter map, sectioned narrative, and references.
- Hide navigation symbols.
- Show frame numbers.
- Use a slim top bar:
  - left: current section title;
  - right: slide-specific frame title or concise content description.
- Keep one principal idea per slide.
- Use `\footnotesize` or `\scriptsize` only where necessary; do not make the entire deck tiny.
- Center code listings and diagrams when this improves balance.
- Use syntax-highlighted `listings` for code.
- Use `booktabs`, `tabularx`, fixed-width columns, and `\raggedright\arraybackslash` for tables.
- Protect short model names from bad line breaks with `\mbox{GPT-1}`, `\mbox{GPT-2}`, and similar commands.
- Do not solve overflow by blindly scaling the whole slide. First shorten text, use columns, move a note to the next slide, or split the slide.
- Architecture slides should normally reserve no more than about `0.68--0.72\textheight` for the main graphic.
- Side explanations should use Beamer `columns` or bounded minipages, not TikZ nodes placed outside the slide canvas.
- Every request of the form “add this to the appendix” creates a new appendix subsection. Do not merge unrelated appendix additions.

### Preferred Beamer structure

1. Title
2. Roadmap
3. Motivation and definitions
4. Architecture or derivation
5. Implementation/code correspondence
6. Training versus inference
7. Summary
8. Appendix, with separate subsections
9. References

## 6. Paper/article defaults

Use these defaults for a paper or technical note unless the user requests a journal template:

- `\documentclass[11pt]{article}`.
- A4 paper with approximately 1-inch margins.
- `lmodern`, `microtype`, `amsmath`, `amssymb`, `mathtools`, `bm`.
- `booktabs`, `array`, `tabularx`, `enumitem`.
- `listings` for implementation code.
- `tikz` for diagrams.
- `hyperref` and `cleveref` for navigation and cross-references.
- Include:
  - title and author information;
  - abstract;
  - table of contents for a substantial document;
  - logically numbered sections and subsections;
  - numbered figures, tables, and equations;
  - captions that explain what the figure shows;
  - references.
- Keep the article implementation-oriented when the source includes code: explain the mathematics, map formulas to code, and state tensor shapes.
- Do not use Beamer-only packages or layout commands in an article.

## 7. Editing an existing TeX project

1. Read the newest source file before editing.
2. Identify the exact frame, section, macro, bibliography, and asset paths involved.
3. Preserve the existing theme and macros unless the user asks for a redesign.
4. Patch the smallest coherent region instead of reconstructing the document from an older version.
5. Keep existing user changes, comments, and custom notation.
6. Create a new revision file and compile that revision.
7. When adding an image, copy it into the project directory and use a relative filename.

## 8. Compilation workflow

Do not require `latexmk`; the user's Windows MiKTeX setup may not have Perl. Prefer direct engine calls.

### No external bibliography

```bash
pdflatex -halt-on-error -file-line-error -interaction=nonstopmode file.tex
pdflatex -halt-on-error -file-line-error -interaction=nonstopmode file.tex
```

### BibTeX project

```bash
pdflatex -halt-on-error -file-line-error -interaction=nonstopmode file.tex
bibtex file
pdflatex -halt-on-error -file-line-error -interaction=nonstopmode file.tex
pdflatex -halt-on-error -file-line-error -interaction=nonstopmode file.tex
```

### Biber project

```bash
pdflatex -halt-on-error -file-line-error -interaction=nonstopmode file.tex
biber file
pdflatex -halt-on-error -file-line-error -interaction=nonstopmode file.tex
pdflatex -halt-on-error -file-line-error -interaction=nonstopmode file.tex
```

- Use pdfLaTeX by default for portability.
- Use XeLaTeX or LuaLaTeX only when Unicode fonts or a supplied template requires them.
- Avoid shell escape unless it is genuinely necessary.

## 9. Mandatory QA gate

After compiling:

1. Check the log for fatal errors, undefined control sequences, missing files, undefined references, and undefined citations.
2. Render the PDF to page images.
3. Inspect every page or slide at normal viewing scale.
4. Fix and recompile until all of the following are true:
   - no clipped text or diagrams;
   - no overlapping nodes, tables, citations, headers, or footers;
   - no content extending beyond the right or bottom edge;
   - no unreadably small labels;
   - no broken glyphs or black boxes;
   - no visibly damaging overfull boxes;
   - no empty or nearly empty accidental pages;
   - no unresolved references or citations;
   - consistent notation, fonts, and colors.
5. Pay special attention to architecture slides, wide tables, references, equations, and appendix pages.

Warnings such as `Overfull \hbox` are not automatically acceptable. Inspect the rendered location and repair it when visible.

## 10. Final response

- Provide direct links to the final `.tex` and `.pdf`.
- Provide the project ZIP when assets are needed.
- Mention only material limitations or unresolved issues.
- Do not report completion before the files have been verified.

## Skill resources

- `templates/article.tex`: paper/article starter.
- `templates/beamer.tex`: Beamer starter with the preferred slim top bar.
- `examples/tikz-architecture.tex`: standalone TikZ architecture example.
- `scripts/build_tex.py`: portable direct-engine build helper that does not require `latexmk`.
